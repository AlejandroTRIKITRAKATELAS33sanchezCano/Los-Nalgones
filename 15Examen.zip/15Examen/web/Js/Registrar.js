function Grupo() {

    var s = document.getElementById('semestre').value;
    var t = document.getElementById('Turno').value;
    var g = document.getElementById('Grupo').value;

    alert(s+"I"+t+g)
    
}